package vijestudio.com;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView1 = findViewById(R.id.recyclerView1);

        List<NegaraModel> negaraModelList = new ArrayList<NegaraModel>();

        NegaraModel nm = new NegaraModel();
        nm.setNama("Albania");
        nm.setDeskripsi("Ini adalah negara Albania. Benderanya berwarna merah.");
        nm.setUrl("http://icons.iconarchive.com/icons/custom-icon-design/all-country-flag/32/Albania-Flag-icon.png");
        negaraModelList.add(nm);

        nm = new NegaraModel();
        nm.setNama("Hungary");
        nm.setDeskripsi("Ini adalah negara Hungary. Bahasa Indonesia-nya adalah Hungaria.");
        nm.setUrl("http://icons.iconarchive.com/icons/custom-icon-design/all-country-flag/32/Hungary-Flag-icon.png");
        negaraModelList.add(nm);

        nm = new NegaraModel();
        nm.setNama("Slovenia");
        nm.setDeskripsi("Ini adalah negara Slovenia. Belum ada deskripsi untuk negera ini.");
        nm.setUrl("http://icons.iconarchive.com/icons/custom-icon-design/all-country-flag/32/Slovenia-Flag-icon.png");
        negaraModelList.add(nm);

        nm = new NegaraModel();
        nm.setNama("Belgium");
        nm.setDeskripsi("Ini adalah negara Belgium. Negara ini terdapat di Eropa.");
        nm.setUrl("http://icons.iconarchive.com/icons/custom-icon-design/all-country-flag/32/Belgium-Flag-icon.png");
        negaraModelList.add(nm);

        nm = new NegaraModel();
        nm.setNama("Canda");
        nm.setDeskripsi("Ini adalah negara Canda. Negara ini terletak di utara Amerika Serika.");
        nm.setUrl("http://icons.iconarchive.com/icons/custom-icon-design/all-country-flag/32/Canada-Flag-icon.png");
        negaraModelList.add(nm);

        RecyclerView.LayoutManager lm = new LinearLayoutManager(MainActivity.this);
        recyclerView1.setLayoutManager(lm);

        NegaraAdapter na = new NegaraAdapter(getApplicationContext(), negaraModelList);
        recyclerView1.setAdapter(na);
    }
}
